
# Práctica 5 - Abstracción y Encapsulamiento

Este proyecto demuestra el uso de abstracción y encapsulamiento en Java mediante las clases `Perro` y `Coche`.

## Instrucciones:
- Ejecuta la clase `Main` para ver la interacción entre las clases `Perro` y `Coche`.
