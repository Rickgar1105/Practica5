
public class Perro {
    private String color;
    private String raza;
    private int edad;
    private String tamaño;

    // Constructor
    public Perro(String color, String raza, int edad, String tamaño) {
        this.color = color;
        this.raza = raza;
        this.edad = edad;
        this.tamaño = tamaño;
    }

    // Getter y Setter
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    // Métodos adicionales
    public void jugar() {
        System.out.println("El perro está jugando");
    }

    public void comer() {
        System.out.println("El perro está comiendo");
    }
}

public class Coche {
    private String[] posiciones = {"Chofer", "Copiloto", "Pasajero1", "Pasajero2"};
    private String[] personas = new String[4];

    // Asignar persona a una posición
    public void asignarPersona(int indice, String nombre) {
        if (indice >= 0 && indice < personas.length) {
            personas[indice] = nombre;
        }
    }

    // Mostrar quién está en cada posición
    public void mostrarPosiciones() {
        for (int i = 0; i < personas.length; i++) {
            System.out.println(posiciones[i] + ": " + (personas[i] != null ? personas[i] : "Vacío"));
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Perro perro = new Perro("Negro", "Labrador", 3, "Grande");
        perro.jugar();
        perro.comer();

        Coche coche = new Coche();
        coche.asignarPersona(0, "Hiram");
        coche.asignarPersona(1, "Ángel");
        coche.asignarPersona(2, "Raúl");
        coche.mostrarPosiciones();
    }
}
